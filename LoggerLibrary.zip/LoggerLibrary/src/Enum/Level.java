package Enum;

public enum Level {
    DEBUG,
    INFO,
    WARN,
    ERROR,
    FATAL;
}
