package Enum;

public enum SinkType {
    FILE,
    CONSOLE,
    DATABASE;
}
