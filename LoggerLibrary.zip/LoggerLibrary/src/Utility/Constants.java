package Utility;

public class Constants {
    private final static int logFileRotationIndexStart = 1;

    public static int getLogfileRotationIndexStart() {
        return logFileRotationIndexStart;
    }

}
